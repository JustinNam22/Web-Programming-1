<?php

$token = $_GET["token"] ?? null;

if (!$token) {
    die("Invalid or missing token.");
}

// Hash the token
$token_hash = hash("sha256", $token);

// Include database connection
$pdo = require __DIR__ . "/dbConnect.php";

// Prepare the SQL query
$sql = "SELECT * FROM users WHERE reset_token_hash = ?";

// Prepare the statement
$stmt = $pdo->prepare($sql);

// Execute the query with the token hash
$stmt->execute([$token_hash]);

// Fetch the user data
$users = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$users) {
    die("Token not found.");
}

// Check if the token has expired
if (strtotime($users["reset_token_expires_at"]) <= time()) {
    die("Token has expired.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | Create New Password</title>
    <link rel="stylesheet" href="new_pass.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Toggle visibility for "New Password"
            const eyeCurrent = document.getElementById("eye-current");
            const newPassword = document.getElementById("new_password");

            eyeCurrent.addEventListener("click", () => {
                const type = newPassword.type === "password" ? "text" : "password";
                newPassword.type = type;
                eyeCurrent.classList.toggle("fa-eye");
                eyeCurrent.classList.toggle("fa-eye-slash");
            });

            // Toggle visibility for "Confirm Password"
            const eyeNew = document.getElementById("eye-new");
            const confirmPassword = document.getElementById("password_confirmation");

            eyeNew.addEventListener("click", () => {
                const type = confirmPassword.type === "password" ? "text" : "password";
                confirmPassword.type = type;
                eyeNew.classList.toggle("fa-eye");
                eyeNew.classList.toggle("fa-eye-slash");
            });

            // Validate passwords on form submission
            const form = document.querySelector("form");
            form.addEventListener("submit", (event) => {
                const password = newPassword.value.trim();
                const confirm = confirmPassword.value.trim();

                if (password.length < 1) {
                    alert("Password must be at least 8 characters long.");
                    event.preventDefault(); // Stop form submission
                }

                if (password !== confirm) {
                    alert("Passwords do not match. Please try again.");
                    event.preventDefault(); // Stop form submission
                }
            });
        });
    </script>
</head>
<body>
<div class="background">

    <div class="reset-password-container">
        <h1>Create New Password</h1>
        <form method="POST" action="process_reset_password.php">
            <div class="input-group">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">
                <input type="password" name="new_password" id="new_password" placeholder="New Password" required style="text-align: center;">
                
            </div>
            <div class="input-group">
                <input type="password" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password" required style="text-align: center;">
             
            </div>
            <button type="submit">Send</button>
        </form>
        <div class="back-home-container">
            <a href="index.php" class="back-home">Back</a>
        </div>
    </div>
</div>
</body>
</html>

