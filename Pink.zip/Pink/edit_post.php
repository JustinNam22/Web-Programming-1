<?php
// Start a new session or resume the existing session
session_start();

// Include the database connection file
require 'dbConnect.php';

// Check if the user or admin is logged in; if not, redirect to the login page
if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php"); // Redirect to the login page
    exit(); // Terminate the script
}

// Retrieve the post ID from the URL, if provided
$post_id = $_GET['post_id'] ?? null;

// Check if post_id is provided; if not, display an error message and exit
if (!$post_id) {
    echo "Invalid post ID."; // Display an error message
    exit(); // Terminate the script
}

try {
    // Prepare an SQL statement to fetch the post data by its ID
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    // Execute the SQL statement with the provided post ID
    $stmt->execute([$post_id]);
    // Fetch the post data as an associative array
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the post exists; if not, display an error message and exit
    if (!$post) {
        echo "Post not found."; // Display an error message
        exit(); // Terminate the script
    }

    // Check if the form is submitted via POST request
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form input values
        $title = $_POST['title']; // Post title
        $content = $_POST['content']; // Post content
        $module_id = $_POST['module_id']; // Module ID
        $imagePath = $post['image']; // Default to the existing image path

        // Handle image upload if a new image is provided
        if (!empty($_FILES['image']['name'])) {
            $targetDir = "uploads/"; // Directory for storing uploaded images
            $imagePath = $targetDir . basename($_FILES['image']['name']); // Full path to the new image
            // Attempt to move the uploaded file to the target directory
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                echo "Failed to upload image."; // Display an error message
                exit(); // Terminate the script
            }
        }

        // Prepare an SQL statement to update the post with the new data
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, module_id = ?, image = ?, updated_at = NOW() WHERE id = ?");
        // Execute the SQL statement with the updated values
        $stmt->execute([$title, $content, $module_id, $imagePath, $post_id]);

        // Redirect to the manage posts page after updating
        header("Location: manage_posts.php");
        exit(); // Terminate the script
    }
} catch (PDOException $e) {
    // Handle any database errors by displaying the error message and terminating the script
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- Set the character encoding for the document -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Ensure proper scaling on mobile devices -->
    <title>Chewsday | Edit Post (Admin)</title> <!-- Page title -->
    <link rel="stylesheet" href="edit_p0st.css"> <!-- Link to the external CSS file -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> <!-- Include a custom font -->
</head>
<body>
<div class="container"> <!-- Container for the form -->
    <h1>Edit Post</h1> <!-- Page heading -->
    <!-- Form for editing the post -->
    <form action="edit_post.php?post_id=<?php echo $post_id; ?>" method="post" enctype="multipart/form-data">
        <label for="title">Title: </label> <!-- Label for the title input -->
        <input type="text-post" name="title" id="title" value="<?php echo htmlspecialchars($post['title']); ?>" required> <!-- Input for the title -->

        <label for="content">Content: </label> <!-- Label for the content textarea -->
        <textarea name="content" id="content" required><?php echo htmlspecialchars($post['content']); ?></textarea> <!-- Textarea for the content -->

        <label for="module_id">Module: </label> <!-- Label for the module selection -->
        <select name="module_id" id="module_id" required> <!-- Dropdown for selecting the module -->
            <option value="1" <?php echo $post['module_id'] == 1 ? 'selected' : ''; ?>>Question</option> <!-- Option for "Question" -->
            <option value="2" <?php echo $post['module_id'] == 2 ? 'selected' : ''; ?>>Article</option> <!-- Option for "Article" -->
            <option value="3" <?php echo $post['module_id'] == 3 ? 'selected' : ''; ?>>Discussion</option> <!-- Option for "Discussion" -->
        </select>

        <label for="image">Upload Image: </label> <!-- Label for the image upload -->
        <input type="file" name="image" id="image"> <!-- Input for the image file -->
        <?php if ($post['image']): ?> <!-- Check if an image exists for the post -->
            <p>Current Image: <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post Image" width="100"></p> <!-- Display the current image -->
        <?php endif; ?>

        <button type="submit">Update Post</button> <!-- Submit button for updating the post -->
    </form>
    <div class="back-home-container"> <!-- Container for the back link -->
        <!-- Conditional back link based on session data -->
        <a href="<?php 
            if (isset($_SESSION['admin_logged_in'])) {
                echo 'manage_posts.php'; // Redirect for admins
            } elseif (isset($_SESSION['user'])) {
                echo 'home.php'; // Redirect for regular users
            } 
        ?>" class="back-home">
            Back <?php 
                if (isset($_SESSION['admin_logged_in'])) {
                    // Admins go to manage posts
                } elseif (isset($_SESSION['user'])) {
                    echo 'Home'; // Users go to home
                } else {
                    echo 'Index'; // Default link
                }
            ?>
        </a>
    </div>
</div>
</body>
</html>
