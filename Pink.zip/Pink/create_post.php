<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="create_p0st.css"> 
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> 
    <title>Chewsday | Create New Post</title> 
</head>
<body> <!-- Begins the body of the HTML document -->
<div class="background"> <!-- Starts a container with the class "background" for styling purposes -->
  
    <div class="question_container"> <!-- Starts a container with the class "question_container" for layout purposes -->
        <h1>Create A New Post</h1> <!-- Displays the heading of the page -->
        <form method="POST" action="create_posts.php" enctype="multipart/form-data"> <!-- Begins a form that uses POST method and sends data to "create_posts.php" with file upload support -->
            <label for="title">Title: </label> <!-- Label for the title input field -->
            <input type="text-post" name="title" id="title" required> <!-- Input field for the title of the post, marked as required -->
            
            <label for="content">Content: </label> <!-- Label for the content input field -->
            <textarea name="content" id="content" required></textarea>  <!-- Textarea input field for the content of the post, marked as required -->

            <label for="module_id">Select module: </label> <!-- Label for the module selection dropdown -->
            <select name="module_id" id="module_id" required=""> <!-- Dropdown to select the module (question, article, discussion), marked as required -->
                              <option value="1">Question</option> <!-- Option for selecting "Question" module -->
                              <option value="2">Article</option> <!-- Option for selecting "Article" module -->
                              <option value="3">Discussion</option> <!-- Option for selecting "Discussion" module -->
            </select>
            
            <label for="image">Upload Image:</label> <!-- Label for the image upload field -->
            <input type="file" name="image" id="image"> <!-- File input field for uploading an image -->
            <button type="submit">Create New Post</button> <!-- Submit button for the form -->
        </form>
        <a href="home.php" class="back-link">Back to Home Page</a> <!-- A link that redirects to the home page -->
    </div>
</div> 
</body> 
</html> 
