<?php
// Start the session to track the admin's login state
session_start();

// Check if the admin is logged in; if not, redirect to the admin login page
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php'); // Redirect to admin login page
    exit(); // Stop further script execution
}

// Validate that a 'module_id' is provided in the URL and is numeric
if (!isset($_GET['module_id']) || !is_numeric($_GET['module_id'])) {
    header('Location: manage_modules.php'); // Redirect to the manage modules page if validation fails
    exit(); // Stop further script execution
}

try {
    // Database connection details
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Data Source Name for MySQL connection
    $username = "root"; // Database username
    $password = ""; // Database password

    // Create a new PDO instance for database interaction
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to throw exceptions

    // Retrieve the module ID from the URL and convert it to an integer
    $module_id = intval($_GET['module_id']);

    // Prepare the SQL statement to delete the module with the specified ID
    $stmt = $pdo->prepare("DELETE FROM modules WHERE id = :module_id");
    $stmt->bindParam(':module_id', $module_id, PDO::PARAM_INT); // Bind the module ID as an integer parameter

    // Execute the prepared statement and check if the deletion was successful
    if ($stmt->execute()) {
        // Redirect to the manage modules page with a success message
        header('Location: manage_modules.php?message=Module+deleted+successfully');
        exit(); // Stop further script execution
    } else {
        // Redirect to the manage modules page with an error message if deletion failed
        header('Location: manage_modules.php?error=Unable+to+delete+module');
        exit(); // Stop further script execution
    }
} catch (PDOException $e) {
    // Handle database connection or query errors and display an error message
    die("Database error: " . $e->getMessage());
}
