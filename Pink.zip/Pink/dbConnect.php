<?php 
// Define the database host
$host = "localhost";

// Define the database name
$dbname = 'hn';

// Define the database username
$username = 'root';

// Define the database password
$password = '';

try {
    // Create a new PDO instance to connect to the database using the provided credentials
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Set the PDO error mode to exception to handle errors gracefully
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Return the PDO object to be used elsewhere in the application
    return $pdo; // Ensure the PDO object is returned
} catch (PDOException $e) {
    // Handle any connection errors by displaying an error message and terminating the script
    die("Database connection failed: " . $e->getMessage());
}
