<?php
session_start(); // Start the session to manage user login state
if (!isset($_SESSION['admin_logged_in'])) { // Check if the admin is logged in
    header('Location: admin_login.php'); // If not, redirect to the login page
    exit(); // Stop the script execution after redirect
}

try {
    // Connect to the database using PDO
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Data Source Name for MySQL database connection
    $username = "root"; // Database username
    $password = ""; // Database password (empty by default for local development)

    $pdo = new PDO($dsn, $username, $password); // Create PDO instance for database connection
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exceptions for better error handling

    // Fetch all users for the dropdown
    $stmt = $pdo->query("SELECT id, name FROM users"); // SQL query to select all users
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch the result as an associative array

    // Fetch all modules for the dropdown
    $stmt = $pdo->query("SELECT id, name FROM modules"); // SQL query to select all modules
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch the result as an associative array

    if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Check if the form has been submitted
        $userId = $_POST['user_id']; // Selected user ID from the form
        $moduleId = $_POST['module_id']; // Selected module ID from the form
        $title = $_POST['title']; // Title from the form
        $content = $_POST['content']; // Content from the form
        $imagePath = null; // Initialize the image path as null

        // Handle image upload
        if (!empty($_FILES['image']['name'])) { // Check if an image was uploaded
            $targetDir = "uploads/"; // Directory where the image will be saved
            $imagePath = $targetDir . basename($_FILES['image']['name']); // Set the file path for the image
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) { // Move the uploaded image to the target directory
                throw new Exception("Failed to upload image."); // If upload fails, throw an exception
            }
        }

        // Insert the post into the database
        $stmt = $pdo->prepare("INSERT INTO posts (user_id, module_id, title, content, image, created_at)
                               VALUES (:user_id, :module_id, :title, :content, :image, NOW())"); // Prepare SQL query to insert post
        $stmt->execute([ // Execute the query with bound parameters
            ':user_id' => $userId,
            ':module_id' => $moduleId,
            ':title' => $title,
            ':content' => $content,
            ':image' => $imagePath, // Bind the image path (or null if no image)
        ]);

        header('Location: manage_posts.php'); // Redirect to the post management page after successful insertion
        exit(); // Stop script execution after redirect
    }
} catch (PDOException $e) { // Catch database-related exceptions
    die("Database error: " . $e->getMessage()); // Display the database error message
} catch (Exception $e) { // Catch other exceptions (e.g., file upload errors)
    die("Error: " . $e->getMessage()); // Display the error message
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | Add Post (Admin)</title> <!-- Page title -->
    <link rel="stylesheet" href="add_p0st.css"> <!-- Link to the external CSS file -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> <!-- Link to Google Fonts for custom font -->

</head>
<body>
    <div class="container"> <!-- Main container div -->
        <h1>Add New Post</h1> <!-- Heading for the page -->
        <form action="add_post.php" method="post" enctype="multipart/form-data"> <!-- Form for adding new post -->
            <label for="user_id">User:</label> <!-- Label for user dropdown -->
            <select name="user_id" id="user_id" required> <!-- Dropdown to select a user -->
                <option value="">Select a User</option> <!-- Default option for user selection -->
                <?php foreach ($users as $user): ?> <!-- Loop through users array and display each user as an option -->
                    <option value="<?= htmlspecialchars($user['id']) ?>"><?= htmlspecialchars($user['name']) ?></option> <!-- Display user ID and name -->
                <?php endforeach; ?> <!-- End of loop -->
            </select>

            <label for="module_id">Module:</label> <!-- Label for module dropdown -->
            <select name="module_id" id="module_id" required> <!-- Dropdown to select a module -->
                <option value="">Select a Module</option> <!-- Default option for module selection -->
                <?php foreach ($modules as $module): ?> <!-- Loop through modules array and display each module as an option -->
                    <option value="<?= htmlspecialchars($module['id']) ?>"><?= htmlspecialchars($module['name']) ?></option> <!-- Display module ID and name -->
                <?php endforeach; ?> <!-- End of loop -->
            </select>

            <label for="title">Title: </label> <!-- Label for title input -->
            <input type="text-post" name="title" id="title" required> <!-- Input field for the title of the post -->

            <label for="content">Content:</label> <!-- Label for content textarea -->
            <textarea name="content" id="content" rows="5" required></textarea> <!-- Textarea for the content of the post -->

            <label for="image">Upload Image</label> <!-- Label for image upload -->
            <input type="file" name="image" id="image" accept="image/*"> <!-- File input to upload an image -->

            <button type="submit" class="button">Add Post</button> <!-- Submit button to submit the form -->
        </form>
        <a href="manage_posts.php" class="back-home">Back to Post Management</a> <!-- Link to go back to post management page -->
    </div>
</body>
</html>
