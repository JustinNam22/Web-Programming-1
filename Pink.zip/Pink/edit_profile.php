<?php
// Start the session to manage user login state and other session data
session_start();

// Include the database connection file
require 'dbConnect.php';

// Redirect the user to the login page if they are not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect to index.php
    exit(); // Stop further script execution
}

// Prepare a query to fetch user information from the database
$stmt = $pdo->prepare("SELECT * FROM users WHERE ID = :id");
$stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT); // Bind the user ID from the session
$stmt->execute(); // Execute the query
$user = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch the user information as an associative array

// Initialize an error message variable to an empty string
$errorMsg = '';

// Check if the form is submitted using the POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name']; // Get the submitted name
    $email = $_POST['email']; // Get the submitted email
    $currentPassword = $_POST['current_password']; // Get the submitted current password
    $newPassword = $_POST['new_password']; // Get the submitted new password

    // Validate form inputs
    if (empty($name) || empty($email) || empty($currentPassword)) {
        $errorMsg = "All fields except 'New Password' are required."; // Set error message if required fields are empty
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMsg = "Invalid email format."; // Set error message for invalid email format
    } else {
        // Check if the provided current password matches the hashed password in the database
        if (password_verify($currentPassword, $user['password'])) {
            // Hash the new password if provided; otherwise, keep the current password
            $password = !empty($newPassword) ? password_hash($newPassword, PASSWORD_DEFAULT) : $user['password'];

            // Prepare an update query to update the user's details in the database
            $updateStmt = $pdo->prepare("UPDATE users SET name = :name, email = :email, password = :password WHERE ID = :id");
            $updateStmt->bindParam(':name', $name); // Bind the updated name
            $updateStmt->bindParam(':email', $email); // Bind the updated email
            $updateStmt->bindParam(':password', $password); // Bind the updated or unchanged password
            $updateStmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT); // Bind the user ID

            // Execute the update query and check for success
            if ($updateStmt->execute()) {
                // Update the session data with the new name and email
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                header("Location: home.php"); // Redirect to the home page
                exit(); // Stop further script execution
            } else {
                $errorMsg = "Error updating profile."; // Set error message for update failure
            }
        } else {
            $errorMsg = "Current password is incorrect."; // Set error message for incorrect current password
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Chewsday | Edit Profile (User)</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
   
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="edit_pr0file.css">
</head>
<body>
<div class="background">

    <div class="profile-check">
        <!-- Page heading -->
        <h1>Edit Profile</h1>
        <!-- Display the error message if it exists -->
        <?php if (!empty($errorMsg)) : ?>
            <div class="error-message"><?php echo htmlspecialchars($errorMsg); ?></div>
        <?php endif; ?>

        <!-- Form for updating user profile details -->
        <form method="POST" action="">
            <!-- Input field for username -->
            <div class="input-group">
                <input type="text" name="name" id="name" placeholder="Please enter your Username" value=<?php echo htmlspecialchars($user['name']); ?> required style="text-align: center;">
            </div>

            <!-- Input field for email -->
            <div class="input-group">
                <input type="email" name="email" id="email" placeholder="Please enter your Email" value="<?php echo htmlspecialchars($user['email']); ?>" required style="text-align: center;">
            </div>

            <!-- Input field for current password -->
            <div class="input-group password">
                <input type="password" name="current_password" id="current_password" placeholder="Please enter your current Password" required style="text-align: center;">
            </div>

            <!-- Input field for new password -->
            <div class="input-group password">
                <input type="password" name="new_password" id="new_password" placeholder="Please make a new Password" required style="text-align: center;">
            </div>

            <!-- Submit button to update profile -->
            <button type="submit">Update Profile</button>
        </form>

        <!-- Link to navigate back to the home page -->
        <a href="home.php" class="back-home">Back to Home Page</a>
    </div>
</div>

</body>
</html>
