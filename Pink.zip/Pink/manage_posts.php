<?php
// Start a new session or resume the current one
session_start();

// Check if the user is not logged in as an admin, if not, redirect to the admin login page
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php'); // Redirect to admin login page
    exit(); // Terminate the script to ensure the user cannot access the page
}

try {
    // Set up database connection using PDO
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Database source name
    $username = "root"; // Database username
    $password = ""; // Database password (empty in this case)

    // Create a new PDO instance
    $pdo = new PDO($dsn, $username, $password);
    
    // Set PDO error mode to exception to handle errors properly
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all posts along with user and module details using a SQL query
    $stmt = $pdo->query("SELECT posts.id, posts.title, posts.content, posts.created_at, users.name AS user_name, modules.name AS module_name
                         FROM posts
                         LEFT JOIN users ON posts.user_id = users.id
                         LEFT JOIN modules ON posts.module_id = modules.id
                         ORDER BY posts.created_at DESC"); // Query to join posts, users, and modules tables
    // Fetch all results as an associative array
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // If there's an error connecting to the database, show the error message
    die("Database error: " . $e->getMessage()); // Display error and stop script execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Set the character encoding to UTF-8 -->
    <meta charset="UTF-8">
    <!-- Set the viewport for responsive design -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Page title -->
    <title>Chewsday | Post Management</title>
    <!-- Link to external CSS file for styling -->
    <link rel="stylesheet" href="manage_p0sts.css">
    <!-- Link to Google Fonts for custom font -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">

    <!-- JavaScript function to handle post deletion -->
    <script>
        function deletePost(postId) {
            // Ask user for confirmation before deleting the post
            if (confirm("Are you sure you want to delete this post?")) {
                // Send a GET request to delete the post
                fetch(`delete_post.php?post_id=${postId}`, {
                    method: 'GET', // Use GET method to send the request
                })
                .then(response => response.text()) // Get the response as plain text
                .then(message => {
                    alert(message); // Alert the response message to the user
                    // If deletion is successful, remove the post from the DOM
                    if (message === "Post deleted successfully.") {
                        document.getElementById(`post-${postId}`).remove(); // Remove post item from the list
                    }
                })
                .catch(error => {
                    console.error("Error:", error); // Log the error if something goes wrong
                    alert("An error occurred. Please try again."); // Alert user about the error
                });
            }
        }
    </script>
</head>
<body>
    <!-- Main container for the content -->
    <div class="container">
        <h1>Post Management</h1>
        <!-- Link to add a new post -->
        <a href="add_post.php" class="button">Add New Post</a>
        <ul>
        <!-- Loop through all posts and display each one -->
        <?php foreach ($posts as $post): ?>
            <li id="post-<?= $post['id'] ?>"> <!-- Set a unique ID for each post -->
                <h2><?= htmlspecialchars($post['title']) ?></h2> <!-- Display the title of the post -->
                <p style="text-align: center;"><strong>Author:</strong> <?= htmlspecialchars($post['user_name']) ?></p> <!-- Display the author's name -->
                <p style="text-align: center;"><strong>Module:</strong> <?= htmlspecialchars($post['module_name']) ?></p> <!-- Display the module name -->
                <p style="text-align: center;"><strong>Created At:</strong> <?= htmlspecialchars($post['created_at']) ?></p> <!-- Display the creation date -->
                <div style="text-align: center;">
                    <!-- Link to edit the post -->
                    <a href="edit_post.php?post_id=<?= $post['id'] ?>" class="button" style="display: inline-block; margin: 5px;">Edit</a>
                    <!-- Link to delete the post using JavaScript function -->
                    <a href="javascript:void(0);" class="button" onclick="deletePost(<?= $post['id'] ?>)" style="display: inline-block; margin: 5px;">Delete</a>
                </div>

                <!-- JavaScript for post deletion, included within each post -->
                <script>
                    function deletePost(postId) {
                        if (confirm("Are you sure you want to delete this post?")) {
                            fetch(`delete_post.php?post_id=${postId}`, {
                                method: 'GET',  // Use GET to keep the URL structure intact
                            })
                            .then(response => response.text()) // Get plain text response from PHP
                            .then(message => {
                                alert(message); // Show the response message
                                if (message === "Post deleted successfully.") {
                                    document.getElementById(`post-${postId}`).remove(); // Remove the post element from DOM
                                }
                            })
                            .catch(error => {
                                console.error("Error:", error);
                                alert("An error occurred. Please try again.");
                            });
                        }
                    }
                </script>

            </li>
        <?php endforeach; ?>
        </ul>
        <!-- Link to go back to the admin home page -->
        <a href="admin_home_page.php" class="back-home">Back to Admin Home Page</a>
    </div>
</body>
</html>
                    