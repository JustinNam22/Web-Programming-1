<?php

// Import necessary PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

// Include the PHPMailer autoloader file
require __DIR__ . "/vendor/autoload.php";

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

// Uncomment this line to enable SMTP debugging (optional)
//$mail->SMTPDebug = SMTP::DEBUG_SERVER;

// Set the mailer to use SMTP
$mail->isSMTP();

// Enable SMTP authentication
$mail->SMTPAuth = true; 

// Set the SMTP server to Gmail's SMTP server
$mail->Host = "smtp.gmail.com";

// Set the encryption method to STARTTLS
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;

// Set the SMTP server port to 587 (for STARTTLS)
$mail->Port = 587;

// Set the SMTP username (your Gmail address)
$mail->Username = "namnhgcs230165@fpt.edu.vn";

// Set the SMTP password (your Gmail app password)
$mail->Password = "tcor fxiu gzkm xvlz";

// Enable HTML email format
$mail->isHTML(true);

// Return the PHPMailer instance (this could be used for further customization or sending the email)
return $mail;
