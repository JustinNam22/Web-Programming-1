<?php
session_start();
require 'dbConnect.php';

// Check login status
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit();
}

// Validate post identifier
$post_id = filter_input(INPUT_GET, 'post_id', FILTER_VALIDATE_INT);
if (!$post_id) {
    die("Invalid post ID provided.");
}

// Handle comment addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['comment'])) {
    $commentText = trim($_POST['comment']);
    $authorId = $_SESSION['user']['id'];
    $authorName = $_SESSION['user']['name'] ?? 'Anonymous';

    if ($commentText) {
        $insertComment = $pdo->prepare("
            INSERT INTO comments (post_id, user_id, name, comment, created_at) 
            VALUES (:post_id, :user_id, :name, :comment, CURRENT_TIMESTAMP)
        ");
        
        $commentData = [
            ':post_id' => $post_id,
            ':user_id' => $authorId,
            ':name' => $authorName,
            ':comment' => $commentText
        ];

        if ($insertComment->execute($commentData)) {
            header("Location: view_post.php?post_id=$post_id");
            exit();
        } else {
            $errorMessage = "Comment submission failed. Please retry.";
        }
    }
}

// Get post information
$postQuery = $pdo->prepare("
    SELECT p.*, u.name AS author_name, m.name AS module_title 
    FROM posts p 
    LEFT JOIN users u ON p.user_id = u.id 
    LEFT JOIN modules m ON p.module_id = m.id 
    WHERE p.id = :post_id
");
$postQuery->execute([':post_id' => $post_id]);
$postData = $postQuery->fetch(PDO::FETCH_ASSOC);

if (!$postData) {
    die("Post not found.");
}

// Get comment list
$commentQuery = $pdo->prepare("
    SELECT c.comment, c.created_at, COALESCE(u.name, 'Anonymous') AS commenter_name 
    FROM comments c 
    LEFT JOIN users u ON c.user_id = u.id 
    WHERE c.post_id = :post_id 
    ORDER BY c.created_at DESC
");
$commentQuery->execute([':post_id' => $post_id]);
$commentList = $commentQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | View Post</title>
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="view_p0st.css">
</head>
<body>
<div class="background">
    <div class="post_container">
        <!-- Post Details -->
        <h1><?php echo htmlspecialchars($postData['title']); ?></h1>
        <div class="post-metadata">
            <p><strong>Author:</strong> <?php echo htmlspecialchars($postData['author_name']); ?></p>
            <p><strong>Module:</strong> <?php echo htmlspecialchars($postData['module_title']); ?></p>
            <p class="post-date"><strong>Published:</strong> 
                <?php echo date("F j, Y, g:i a", strtotime($postData['created_at'])); ?>
            </p>
        </div>

        <!-- Post Body -->
        <div class="post-content">
            <p><strong>Content:</strong> <?php echo nl2br(htmlspecialchars($postData['content'])); ?></p>
            <?php if ($postData['image']): ?>
                <div class="post-image">
                    <img src="<?php echo htmlspecialchars($postData['image']); ?>" alt="Post Image">
                </div>
            <?php endif; ?>
        </div>

        <!-- Add Comment -->
        <div class="comment-form">
            <form method="POST">
                <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
                <h2>Leave a comment:</h2>
                <textarea name="comment" id="comment" required></textarea>
                <button type="submit">Share your thought!</button>
            </form>
        </div>

        <!-- Comment List -->
        <div class="comments-section">
            <h3>Comments:</h3>
            <?php if ($commentList): ?>
                <?php foreach ($commentList as $comment): ?>
                    <div class="answer">
                        <p class="commenter"><strong><?php echo htmlspecialchars($comment['commenter_name']); ?></strong></p>
                        <p class="comment"><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                        <p class="comment-date">
                            <?php echo date("F j, Y, g:i a", strtotime($comment['created_at'])); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="no-comments">Be the first to comment on this post!</p>
            <?php endif; ?>
        </div>

        <a href="home.php" class="back-home">Back to Home Page</a>
    </div>
</div>
</body>
</html>