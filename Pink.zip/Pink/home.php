<?php
// Initialize user session
session_start();
include 'dbConnect.php';

// Validate user authentication
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    die();
}

// Extract user information
$currentUser = $_SESSION['user'];

// Fetch all posts from the database
$postQuery = $pdo->query("SELECT p.id AS post_id, p.title AS post_title, 
                                p.created_at AS creation_date, 
                                p.updated_at AS modification_date, 
                                p.user_id AS author_id, 
                                u.name AS author_name 
                         FROM posts p
                         INNER JOIN users u ON p.user_id = u.id 
                         ORDER BY p.created_at DESC");
$allPosts = $postQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | Home</title>
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="h0me.css">
</head>
    
<body>
<div class="background">
    <div class="home_container">
        <div class="welcome">
            <h1>Welcome to Chewsday, <?php echo htmlspecialchars($currentUser['name']); ?>!</h1>
            <p style="text-align: center;"><b>Username:</b> <?php echo htmlspecialchars($currentUser['name']); ?></p>
            <p style="text-align: center;"><b>Email:</b> <?php echo htmlspecialchars($currentUser['email']); ?></p>

            <nav class="user-actions">
                <a href="create_post.php" class="home-button">Create post</a>
                <a href="edit_profile.php" class="home-button">Edit profile</a>
                <a href="mailto:namnhgcs230165@fpt.edu.vn" class="home-button">Contact Admin</a>
                <a href="logout.php" class="home-button">Log Out</a>
            </nav>

            <section class="posts">
                <h3>All Posts</h3>
                
                <?php foreach ($allPosts as $entry): ?>
                    <article class="post" id="post-<?php echo $entry['post_id']; ?>">
                        <h3>
                            <a href="view_post.php?post_id=<?php echo $entry['post_id']; ?>">
                                <?php echo htmlspecialchars($entry['post_title']); ?>
                            </a>
                        </h3>
                        
                        <div class="post-metadata">
                            <p>Posted by: <?php echo htmlspecialchars($entry['author_name']); ?></p>
                            <p>Posted on: <?php echo date("d/m/Y, H:i", strtotime($entry['creation_date'])); ?></p>
                            <?php if (!empty($entry['modification_date'])): ?>
                                <p>Updated on: <?php echo date("d/m/Y, H:i", strtotime($entry['modification_date'])); ?></p>
<?php endif; ?>
                        </div>

                        <?php if ($currentUser['id'] === $entry['author_id']): ?>
                            <div class="post-actions">
                                <a href="edit_post_user.php?post_id=<?php echo $entry['post_id']; ?>" 
                                   class="home-button">Edit</a>
                                <a href="delete_post.php?post_id=<?php echo $entry['post_id']; ?>" 
                                   class="home-button"
                                   onclick="return confirm('Are you sure you want to delete this post?');">Delete</a>
                            </div>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </section>
        </div>
    </div>
</div>
</body>
</html>