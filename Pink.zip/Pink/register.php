<?php
// Start a new session or resume the current session
session_start();

// Retrieve any error messages stored in the session, if available
$errors = $_SESSION['errors'] ?? [];

// Function to display error messages based on the given key
function showError($key) {
    // Declare the global $errors variable to access it within the function
    global $errors;
    
    // Check if there is an error message for the specified key
    if (isset($errors[$key])) {
        // Sanitize the error message to prevent XSS attacks
        $message = htmlspecialchars($errors[$key]);
        
        // Set the class for the error message, different style for 'user_exist' key
        $class = ($key === 'user_exist') ? 'error-main' : 'error';
        
        // Output the error message wrapped in a div with the appropriate class
        echo "<div class='$class'><p>$message</p></div>";
        
        // If the error key is not 'name', remove it from the errors array
        if ($key !== 'name') {
            unset($errors[$key]);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Set the character encoding to UTF-8 -->
    <meta charset="UTF-8">
    
    <!-- Make the website responsive by setting the viewport -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Set the title of the page -->
    <title>Chewsday | Create Account</title>
    
    <!-- Link to an external CSS file for the form's styling -->
    <link rel="stylesheet" href="create_account.css">
    
    <!-- Link to an external stylesheet for Font Awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Link to Google Fonts to use the Anton font -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>

<body>
    <!-- Main container for the page background and profile section -->
    <div class="background">
        <!-- Container for the signup form -->
        <div class="profile-check" id="signup">
            
            <!-- Header section with title and designer name -->
            <header>
                <h1 class="form-title">Chewsday</h1>
                <h2>Designed By Justin Nam</h2>
            </header>
            
            <!-- Display any 'user_exist' error message -->
            <?php showError('user_exist'); ?>

            <!-- Start the form for account creation, method POST, action 'user-account.php' -->
            <form method="POST" action="user-account.php">
                
                <!-- Input group for entering username -->
                <div class="input-group">
                    <!-- Text input for username, required field with centered text -->
                    <input 
                        type="text" 
                        name="name" 
                        id="name" 
                        placeholder="Please enter your Username" 
                        required 
                        style="text-align: center;"
                    >
                    <!-- Display any error related to the 'name' field -->
                    <?php showError('name'); ?>
                </div>

                <!-- Input group for entering email address -->
                <div class="input-group">               
                    <!-- Email input, required field with centered text -->
                    <input 
                        type="email" 
                        name="email" 
                        id="email" 
                        placeholder="Please enter your Email" 
                        required 
                        style="text-align: center;"
                    >
                    <!-- Display any error related to the 'email' field -->
                    <?php showError('email'); ?>
                </div>

                <!-- Input group for entering password -->
                <div class="input-group password">              
                    <!-- Password input, required field with centered text -->
                    <input 
                        type="password" 
                        name="password" 
                        id="password" 
                        placeholder="Please make your Password" 
                        required 
                        style="text-align: center;"
                    >
                    <!-- Display any error related to the 'password' field -->
                    <?php showError('password'); ?>
                </div>

                <!-- Input group for confirming password -->
                <div class="input-group">
                    <!-- Password confirmation input, required field with centered text -->
                    <input 
                        type="password" 
                        name="confirm_password" 
                        placeholder="Please confirm your Password" 
                        required 
                        style="text-align: center;"
                    >
                    <!-- Display any error related to the 'confirm_password' field -->
                    <?php showError('confirm_password'); ?>
                </div>

                <!-- Submit button for form submission -->
                <input type="submit" class="btn" value="Create Account" name="signup">
            </form>

            <!-- Navigation links below the form -->
            <nav class="links">
                <!-- Text prompting user to log in if they already have an account -->
                <p>Already Have An Account ?</p>
                <!-- Link to the login page -->
                <a href="index.php">Log In</a>
            </nav>
        </div>
    </div>

    <!-- Link to an external JavaScript file for any required scripts -->
    <script src="script.js"></script>
</body>

</html>

<?php
// After processing, clear any stored error messages from the session
if(isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
?>
