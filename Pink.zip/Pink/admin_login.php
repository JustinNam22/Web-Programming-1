<?php
session_start(); // Start a session to store error messages and user session data

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Check if the form is submitted using the POST method
    $adminUsername = $_POST['texts'];     // Get the username input from the form
    $adminPassword = $_POST['passwords']; // Get the password input from the form

    try {
        // Initialize database connection
        $dbConnection = new PDO('mysql:host=localhost;dbname=hn', 'root', ''); // Connect to the database
        $dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set the error mode to exception

        // Search for admin credentials
        $queryAdmin = $dbConnection->prepare('SELECT id, username, password FROM admins WHERE username = :username'); // Prepare the SQL query to search for the admin username
        $queryAdmin->bindParam(':username', $adminUsername); // Bind the admin username to the query
        $queryAdmin->execute(); // Execute the query

        if ($queryAdmin->rowCount() > 0) { // Check if any record was found
            $adminData = $queryAdmin->fetch(PDO::FETCH_ASSOC); // Fetch the admin data

            // Validate password
            if (password_verify($adminPassword, $adminData['password'])) { // Check if the entered password matches the stored hash
                // Create admin session
                $_SESSION['admin_logged_in'] = true; // Set session variable for logged-in status
                $_SESSION['admin'] = [ // Store admin details in session
                    'id' => $adminData['id'],
                    'username' => $adminData['username']
                ];
                header('Location: admin_home_page.php'); // Redirect to the admin home page
                exit(); // Stop further execution
            } else {
                $_SESSION['errors']['hn'] = 'Incorrect username or password.'; // Set error message if password is incorrect
            }
        } else {
            $_SESSION['errors']['hn'] = 'Admin account does not exist.'; // Set error message if username is not found
        }
    } catch (PDOException $dbError) { // Catch any database connection errors
        $_SESSION['errors']['hn'] = 'Connection error: ' . $dbError->getMessage(); // Set error message for connection error
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- Set character encoding for the document -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Set the viewport for responsive design -->
    <title>Chewsday | Admin Login</title> <!-- Set the title of the page -->
    <link rel="stylesheet" href="admin_l0gin.css"> <!-- Link to the external CSS file for styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Link to Font Awesome for icons -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> <!-- Link to Google Fonts for custom font -->
</head>
<body>

        <div class="form-container"> <!-- Container for the login form -->
            <h1>Admin Login</h1> <!-- Heading for the page -->

            <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?> <!-- Check if there are any errors in the session -->
                <div class="error-container"> <!-- Container for error messages -->
                    <?php foreach ($_SESSION['errors'] as $error): ?> <!-- Loop through all error messages -->
                        <p class="error-message"><?php echo htmlspecialchars($error); ?></p> <!-- Display each error message safely -->
                    <?php endforeach; ?>
                </div>
            <?php unset($_SESSION['errors']); endif; ?> <!-- Clear error messages after displaying -->

            <form method="POST"> <!-- Login form with POST method -->
                <div class="input-group"> <!-- Container for username input -->
                    <input type="text" name="texts" placeholder="Please enter Admin Username" required style="text-align: center;"> <!-- Username input field -->
                </div>
                <div class="input-group password"> <!-- Container for password input -->
                    <input type="password" name="passwords" id="password" placeholder="Please enter Admin Password" required style="text-align: center;"> <!-- Password input field -->
                </div>
                <button type="submit">Log In</button> <!-- Submit button for the form -->
            </form>

            <!-- Additional links -->
            <div class="additional-links"> <!-- Container for additional links -->
                <a href="admin_register.php" class="register-link">Admin Register</a> <!-- Link to the admin registration page -->
                <a href="index.php" class="back-links">Back</a> <!-- Link to the main website page -->
            </div>
        </div>

        <script>
            const passwordField = document.getElementById('password'); // Get the password input element by ID
            // Eye icon logic is missing, but this section would toggle the password visibility if implemented.
            // eyeIcon.addEventListener('click', () => {
            //     const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            //     passwordField.setAttribute('type', type);
            // });

            // Show error message in an alert if set
            <?php if (isset($_SESSION['errors']['hn'])): ?> <!-- Check if there's an error in the session -->
            alert("<?php echo $_SESSION['errors']['hn']; ?>"); <!-- Display the error message in an alert -->
            <?php unset($_SESSION['errors']['hn']); endif; ?> <!-- Clear the error message from session after alert -->
        </script>
    </div>
</body>
</html>
