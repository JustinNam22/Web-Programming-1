<?php
// Start the session to access session variables
session_start();

// Check if the admin is logged in; if not, redirect to the admin login page
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php'); // Redirect to admin login page
    exit(); // Stop further script execution
}

try {
    // Set up the Data Source Name (DSN) for the database connection
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4";
    $username = "root"; // Database username
    $password = ""; // Database password

    // Create a new PDO instance for database connection
    $pdo = new PDO($dsn, $username, $password);

    // Set the PDO error mode to exception for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the 'user_id' parameter is provided in the URL
    if (isset($_GET['user_id'])) {
        // Convert the 'user_id' parameter to an integer
        $user_id = intval($_GET['user_id']);

        // Prepare the SQL statement to delete a user by their ID
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        
        // Execute the prepared statement with the user ID as a parameter
        $stmt->execute([$user_id]);

        // Redirect back to the manage users page after deletion
        header("Location: manage_users.php");
        exit(); // Stop further script execution
    } else {
        // Display an error message if 'user_id' is invalid or missing
        die("Invalid user ID.");
    }
} catch (PDOException $e) {
    // Catch and handle any PDO-related errors
    die("Database error: " . $e->getMessage());
}
?>
