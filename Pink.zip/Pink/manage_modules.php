<?php
session_start(); // Starts the session to keep track of the logged-in user

// Checks if the 'admin_logged_in' session variable is not set
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php'); // Redirects to the login page if not logged in
    exit(); // Stops further execution of the script
}

try {
    // Connect to the database using PDO with the specified details
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Database connection details
    $username = "root"; // Database username
    $password = ""; // Database password

    // Creates a PDO instance and sets the error mode to exception
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Sets PDO to throw exceptions on errors

    // Executes a query to fetch all modules from the 'modules' table
    $stmt = $pdo->query("SELECT id, name FROM modules");
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetches the result as an associative array
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage()); // Catches any database connection errors and displays the message
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Chewsday | Manage Modules</title> 
    <link rel="stylesheet" href="manage_m0dules.css"> 
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> 
</head>
<body>
    <div class="container"> <!-- Container for the content -->
        <h1>Manage Modules</h1> <!-- Page heading -->
        <a href="add_module.php" class="button">Add New Module</a> <!-- Link to the page where a new module can be added -->
        <ul> <!-- Start of an unordered list -->
            <?php foreach ($modules as $module): ?> <!-- Loops through each module fetched from the database -->
                <li> <!-- List item for each module -->
                    <h2><?= htmlspecialchars($module['name']) ?></h2> <!-- Displays the module name with special characters escaped -->
                    <a href="delete_module.php?module_id=<?= $module['id'] ?>" class="button" 
                       onclick="return confirm('Are you sure you want to delete this module?');">Delete</a> <!-- Delete button with a confirmation prompt -->
                </li> <!-- End of list item -->
            <?php endforeach; ?> <!-- Ends the loop through modules -->
        </ul> <!-- End of unordered list -->
        <a href="admin_home_page.php" class="back-home">Back to admin dashboard</a> <!-- Link to go back to the admin dashboard -->
    </div> <!-- End of the container -->
</body>
</html>
