<?php
session_start(); // Start a new or resume an existing session to manage user data.
require 'dbConnect.php'; // Include the database connection file for database interactions.

if ($_SERVER['REQUEST_METHOD'] == 'POST') { // Check if the form has been submitted using the POST method.
    $title = trim($_POST['title']); // Get the title from the form and trim whitespace.
    $content = trim($_POST['content']); // Get the content from the form and trim whitespace.
    $module_id = intval($_POST['module_id']); // Convert the module ID from the form to an integer.
    $imagePath = null; // Initialize the image path to null, assuming no image is provided.

    // Validate required fields to ensure none of them are empty.
    if (empty($title) || empty($content) || empty($module_id)) {
        echo "All fields are required."; // Output an error message if validation fails.
        exit(); // Stop further execution if validation fails.
    }

    // Check if an image file has been uploaded.
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "uploads/"; // Define the directory where uploaded images will be stored.
        $imageName = basename($_FILES['image']['name']); // Get the base name of the uploaded image file.
        $targetFile = $targetDir . uniqid() . "_" . $imageName; // Create a unique filename for the image.

        // Attempt to move the uploaded file to the target directory.
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = $targetFile; // Store the relative path to the uploaded image if successful.
        } else {
            echo "Error uploading image."; // Output an error message if the upload fails.
            exit(); // Stop further execution if the upload fails.
        }
    }

    // Prepare an SQL statement to insert the post data into the database.
    $stmt = $pdo->prepare("
        INSERT INTO posts (title, content, image, user_id, module_id, created_at) 
        VALUES (:title, :content, :image, :user_id, :module_id, NOW())
    ");
    $stmt->bindParam(':title', $title); // Bind the title parameter to the SQL statement.
    $stmt->bindParam(':content', $content); // Bind the content parameter to the SQL statement.
    $stmt->bindParam(':user_id', $_SESSION['user']['id']); // Bind the user ID from the session to the SQL statement.
    $stmt->bindParam(':module_id', $module_id); // Bind the module ID to the SQL statement.

    // Bind the image parameter if an image path exists, otherwise bind null.
    if ($imagePath !== null) {
        $stmt->bindParam(':image', $imagePath); // Bind the image path if an image is uploaded.
    } else {
        $stmt->bindValue(':image', null, PDO::PARAM_NULL); // Bind null if no image is provided.
    }

    // Execute the SQL statement and check if the post was saved successfully.
    if ($stmt->execute()) {
        header("Location: home.php"); // Redirect to the home page upon successful insertion.
        exit(); // Stop further execution after redirecting.
    } else {
        echo "Error saving post."; // Output an error message if the insertion fails.
    }
}
?>
