<?php
session_start();  // Starts the session or resumes the current session

// Check if the 'admin_logged_in' session variable is not set, meaning the admin is not logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');  // Redirect to the admin login page if not logged in
    exit();  // Stop further execution after the redirection
}

try {
    // Connect to the database using PDO (PHP Data Objects)
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4";  // Define the database connection details (host, database name, charset)
    $username = "root";  // Set the database username
    $password = "";  // Set the database password (empty in this case)

    // Create a new PDO instance to connect to the database
    $pdo = new PDO($dsn, $username, $password);
    // Set the PDO error mode to throw exceptions (useful for debugging)
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted via POST method
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $moduleName = trim($_POST['module_name']);  // Retrieve and trim any extra spaces from the 'module_name' form field

        // Validate the module name to ensure it is not empty
        if (empty($moduleName)) {
            $error = "Module name cannot be empty.";  // Set an error message if the module name is empty
        } else {
            // Prepare the SQL statement to insert the new module into the 'modules' table
            $stmt = $pdo->prepare("INSERT INTO modules (name) VALUES (:name)");
            // Execute the prepared statement, binding the module name to the placeholder ':name'
            $stmt->execute(['name' => $moduleName]);

            // Redirect to the manage_modules.php page after the module is added successfully
            header('Location: manage_modules.php');
            exit();  // Stop further execution after the redirection
        }
    }
} catch (PDOException $e) {
    // If a database error occurs, display the error message and stop execution
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Chewsday | Add Module</title>  <!-- Set the title of the webpage which appears on the browser tab -->

    <!-- Link to Google Fonts to import the 'Anton' font -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <!-- Link to the external CSS file for styling the page -->
    <link rel="stylesheet" href="add_m0dule.css">  <!-- Add the external CSS file to style the page -->
</head>
<body>  <!-- Begin the body section of the HTML document -->

    <div class="container">  <!-- A wrapper div to contain the content on the page -->
        <h1>Add New Module</h1>  <!-- Heading for the page that indicates the purpose of the page -->

        <!-- Check if there is an error message and display it -->
        <?php if (isset($error)): ?>  <!-- Check if the error variable is set -->
            <p class="error"><?= htmlspecialchars($error) ?></p>  <!-- Display the error message safely, escaping special characters -->
        <?php endif; ?>  <!-- End the error message block -->

        <!-- Form to submit the new module -->
        <form method="post" action="add_module.php">  <!-- The form sends the POST request to the same page -->
            <label for="module_name">Enter Module Name:</label>  <!-- Label for the input field with the ID 'module_name' -->

            <!-- Input field for the module name; 'required' ensures the field cannot be left empty -->
            <input type="text-post" id="module_name" name="module_name" required>  

            <!-- Submit button to submit the form -->
            <button type="submit" class="button">Add Module</button>  <!-- Button to submit the form -->
        </form>

        <!-- Link to navigate back to the 'manage_modules.php' page -->
        <a href="manage_modules.php" class="back-home">Back to Manage Modules</a>  <!-- Link to go back to the modules management page -->
    </div> 
</body>
</html> 
