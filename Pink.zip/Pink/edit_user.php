<?php
// Start the session to manage user authentication
session_start();

// Check if the admin is logged in; if not, redirect to the login page
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php'); // Redirect to admin login
    exit(); // Terminate script execution
}

try {
    // Connect to the database using PDO
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Data Source Name specifying host, database, and charset
    $username = "root"; // Database username
    $password = ""; // Database password
    $pdo = new PDO($dsn, $username, $password); // Create a new PDO instance
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set error mode to exception

    // Check if the user_id is provided in the GET request
    if (isset($_GET['user_id'])) {
        $user_id = intval($_GET['user_id']); // Sanitize and convert user_id to an integer

        // Prepare and execute a query to fetch user data based on user_id
        $stmt = $pdo->prepare("SELECT id, name, email FROM users WHERE id = ?");
        $stmt->execute([$user_id]); // Execute the query with the provided user_id
        $user = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch the result as an associative array

        // Check if the user exists
        if (!$user) {
            die("User not found!"); // Terminate script if the user is not found
        }

        // Handle form submission for updating user data
        if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Check if the request method is POST
            $name = trim($_POST['name']); // Retrieve and trim the name input
            $email = trim($_POST['email']); // Retrieve and trim the email input

            // Check if both name and email fields are filled
            if ($name && $email) {
                // Prepare and execute an update query to modify user data
                $updateStmt = $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
                $updateStmt->execute([$name, $email, $user_id]); // Execute the update query with new values

                header("Location: manage_users.php"); // Redirect to the manage users page
                exit(); // Terminate script execution
            } else {
                $error = "Please fill in all fields."; // Set an error message if fields are empty
            }
        }
    } else {
        die("Invalid user ID."); // Terminate script if user_id is not provided
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage()); // Handle database connection or query errors
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> <!-- Set the character encoding for the document -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Set the viewport for responsive design -->
    <title>Chewsday | Edit User</title> <!-- Set the page title -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> <!-- Import a Google font -->
    <link rel="stylesheet" href="edit_userz.css"> <!-- Link to an external CSS file -->
</head>
<body>
    <div class="container"> <!-- Main container for the page content -->
        <h1>Edit User</h1> <!-- Page header -->
        <?php if (isset($error)): ?> <!-- Check if an error message is set -->
            <p class="error"><?= htmlspecialchars($error) ?></p> <!-- Display the error message safely -->
        <?php endif; ?>
        <form method="POST"> <!-- Start a form with POST method -->
            <label for="name">Name:</label> <!-- Label for the name input field -->
            <input type="text" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required> <!-- Text input for name, prefilled with current value -->
            <label for="email">Email:</label> <!-- Label for the email input field -->
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required> <!-- Email input for email, prefilled with current value -->
            <button type="submit" class="button">Save Changes</button> <!-- Submit button for the form -->
        </form>
        <a href="manage_users.php" class="back-home">Back to Manage Users</a> <!-- Link to go back to the manage users page -->
    </div>
</body>
</html>
