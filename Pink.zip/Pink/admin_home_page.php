<?php
// Start a new session or resume the existing session
session_start();

// Check if the admin is logged in by verifying the session variable
if (!isset($_SESSION['admin_logged_in'])) {
    // Redirect to the admin login page if the admin is not logged in
    header('Location: admin_login.php');
    // Exit the script to prevent further code execution
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Chewsday | Admin Home Page</title>
    
    <link rel="stylesheet" href="admin_h0me_page.css">
   
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>
<body>

<!-- Container div for the form content -->
<div class="form-container">
    <!-- Admin Dashboard section -->
    <div class="admin_dashboard">
        <!-- Main heading of the Admin page -->
        <h1>Admin Home Page</h1>
        <!-- Subheading for Users Management section -->
        <h2>Chewsday</h2>
        <!-- Unordered list of options for managing different sections -->
        <ul>
            <!-- List item linking to the Manage Posts page -->
            <li><a href="manage_posts.php">Manage Posts</a></li>
            <!-- List item linking to the Manage Users page -->
            <li><a href="manage_users.php">Manage Users</a></li>
            <!-- List item linking to the Manage Modules page -->
            <li><a href="manage_modules.php">Manage Modules</a></li>
        </ul>
        <!-- Link to log out the admin and redirect to the logout page -->
        <a href="logout.php" class="home-button">Log Out</a>
    </div>

</div>
</body>
</html>
