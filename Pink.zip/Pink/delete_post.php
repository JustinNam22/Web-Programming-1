<?php
// Start a session to manage session variables and user authentication
session_start();

// Check if a 'post_id' is provided via a GET request
if (isset($_GET['post_id'])) {
    // Retrieve the 'post_id' from the GET request and convert it to an integer
    $postId = intval($_GET['post_id']);

    try {
        // Define the Data Source Name (DSN) for connecting to the MySQL database
        $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4";
        // Define the username for the database connection
        $username = "root";
        // Define the password for the database connection
        $password = "";
        // Create a new PDO instance for connecting to the database
        $pdo = new PDO($dsn, $username, $password);
        // Set the PDO error mode to exception for better error handling
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare a SQL statement to delete a post with the specified ID
        $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
        // Execute the prepared statement with the 'post_id' as a parameter
        $stmt->execute([$postId]);

        // Check if any rows were affected by the DELETE operation
        if ($stmt->rowCount() > 0) {
            // If rows were affected, the post was deleted successfully
            echo "Post deleted successfully.";
        } else {
            // If no rows were affected, the post was not found or already deleted
            echo "Post not found or already deleted.";
        }
    } catch (PDOException $e) {
        // Handle any PDO exceptions and display the error message
        echo "Database error: " . $e->getMessage();
    }
} else {
    // If 'post_id' is not provided in the GET request, display an error message
    echo "Invalid request.";
}
