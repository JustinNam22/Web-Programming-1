<?php

// Include the database connection file
$pdo = require __DIR__ . "/dbConnect.php";

// Initialize a variable to store messages
$message = "";

// Check if the form is submitted using POST method
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if the email field is set in the form
    if (isset($_POST["email"])) {
        // Get the email value entered in the form
        $email = $_POST["email"];

        // Generate a secure random token and convert it to hexadecimal
        $token = bin2hex(random_bytes(16));
        // Hash the generated token using SHA-256
        $token_hash = hash("sha256", $token);

        // Set the token expiration time (30 minutes from the current time)
        $expiry = date("Y-m-d H:i:s", time() + 60 * 30);

        // SQL query to update the user's reset token and expiration time in the database
        $sql = "UPDATE users 
                SET reset_token_hash = :token_hash, 
                    reset_token_expires_at = :expiry 
                WHERE email = :email";

        // Prepare the SQL statement for execution
        $stmt = $pdo->prepare($sql);
        // Bind the token hash to the SQL statement
        $stmt->bindValue(':token_hash', $token_hash, PDO::PARAM_STR);
        // Bind the expiration time to the SQL statement
        $stmt->bindValue(':expiry', $expiry, PDO::PARAM_STR);
        // Bind the email to the SQL statement
        $stmt->bindValue(':email', $email, PDO::PARAM_STR);
        // Execute the SQL statement
        $stmt->execute();

        // Check if the update query affected any rows (i.e., email exists in the database)
        if ($stmt->rowCount() > 0) {
            // Include the mailer configuration to send the reset email
            $mail = require __DIR__ . "/mailer.php";

            // Configure the mailer with the sender's email address
            $mail->setFrom("noreply@example.com");
            // Add the recipient email address
            $mail->addAddress($email);
            // Set the subject of the email
            $mail->Subject = "Chewsday | Create New Password";
            // Set the body of the email with a link to the reset password page
            $mail->Body = <<<END
Click <a href="http://localhost/Pink/reset_password.php?token=$token">here</a> to create new password.
END;

            // Try to send the email and handle any exceptions if they occur
            try {
                // Send the email
                $mail->send();
                // Set a success message to be displayed
                $message = "Create new password request mail has been sent. Please check your Email !!! ";
            } catch (Exception $e) {
                // Set an error message if the email sending fails
                $message = "Failed to send email. Error: " . $mail->ErrorInfo;
            }
        } else {
            // Set a message if the email is not found in the database
            $message = "Email not found. Please create an account !!!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | Forgot Password</title>
    <!-- Include the CSS for the forgot password page -->
    <link rel="stylesheet" href="forgo.css">
    <!-- Include Font Awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Include the Anton font from Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>
<body>
    <div class="background">

    <div class="forgot-password-container">
        <!-- Display the message if set (Success or Error) -->
        <?php if (!empty($message)): ?>
            <script>
                // Show an alert with the message
                alert("<?php echo $message; ?>");
            </script>
        <?php endif; ?>

        <div class="profile-check">
            <!-- Title of the form -->
            <h1 class="form-title">Forgot Password</h1>
            <!-- Form to submit email for password reset -->
            <form method="POST" action="forgot_password.php">
                <div class="input-group">
                <!-- Email input field -->
                <input type="email" name="email" id="email" placeholder="Email" required>
                </div>
                <div class="button-container">
                    <!-- Submit button for sending the reset link -->
                    <button type="submit">Send Link</button>
                </div>
            </form>
            <!-- Link to navigate back to the login page -->
            <div class="back-home-container">
                <a href="index.php" class="back-home">Back to Login Page</a>
            </div>
 
    </div>
</body>
</html>
