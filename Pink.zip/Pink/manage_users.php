<?php
session_start(); // Start the session to check if the user is logged in
if (!isset($_SESSION['admin_logged_in'])) { // Check if the admin is logged in
    header('Location: admin_login.php'); // If not, redirect to the login page
    exit(); // Stop further script execution
}

try {
    // Connect to the database using PDO
    $dsn = "mysql:host=localhost;dbname=hn;charset=utf8mb4"; // Database connection string
    $username = "root"; // Database username
    $password = ""; // Database password

    $pdo = new PDO($dsn, $username, $password); // Create PDO object for database connection
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Set PDO error mode to exception

    // Fetch all users from the database
    $stmt = $pdo->query("SELECT id, name, email, created_at FROM users ORDER BY created_at DESC"); // Query to fetch users ordered by creation date
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all users as associative array
} catch (PDOException $e) { // Catch any database-related errors
    die("Database error: " . $e->getMessage()); // Display the error message and stop the script
}
?>

<!DOCTYPE html>
<html lang="en"> <!-- Start of the HTML document -->
<head>
    <meta charset="UTF-8"> <!-- Set the character encoding to UTF-8 -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Set viewport for responsiveness -->
    <title>Chewsday | Manage User</title> <!-- Set the title of the page -->
    <link rel="stylesheet" href="manage_userz.css"> <!-- Link to the external CSS file -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet"> <!-- Link to Google Fonts for styling -->
</head>
<body>
    <div class="container"> <!-- Start of the main container div -->
        <h1>Manage Users</h1> <!-- Heading of the page -->

        <ul> <!-- Start of an unordered list to display users -->
            <?php foreach ($users as $user): ?> <!-- Loop through all users and display them -->
                <li> <!-- Start of a list item for each user -->
                    <h2><?= htmlspecialchars($user['name']) ?> </h2> <!-- Display the user's name safely using htmlspecialchars -->
                    <div style="text-align: center; margin: 0 auto; padding: 20px;"> <!-- Inline styling for centering and padding -->
                        <p><strong>Email: </strong><?= htmlspecialchars($user['email']) ?></p> <!-- Display the user's email -->
                        <p><strong>Registered At:</strong> <?= htmlspecialchars($user['created_at']) ?></p> <!-- Display the user's registration date -->
                        <!-- Link to edit the user information -->
                        <a href="edit_user.php?user_id=<?= $user['id'] ?>" class="button" style="display: inline-block; padding: 10px 20px; margin: 10px;; color: #a16b25; text-decoration: none; border-radius: 5px;">Edit</a>
                        <!-- Link to delete the user with a confirmation prompt -->
                        <a href="delete_user.php?user_id=<?= $user['id'] ?>" class="button" style="display: inline-block; padding: 10px 20px; margin: 10px; ; color: #a16b25; text-decoration: none; border-radius: 5px;" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                    </div>
                </li> <!-- End of the list item for each user -->

            <?php endforeach; ?> <!-- End of the loop for users -->
        </ul> <!-- End of the unordered list -->
        <!-- Link to go back to the admin home page -->
        <a href="admin_home_page.php" class="back-home">Back to Admin Home Page</a>
    </div> <!-- End of the container div -->
</body>
</html>
