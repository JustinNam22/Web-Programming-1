<?php
session_start();
$errors = $_SESSION['errors'] ?? null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chewsday | Log In</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="layout.css">
</head>

<body>
    <div class="background">
        <div class="profile-check" id="signIn">
            <h1 class="form-title">Chewsday</h1>
            <h2>Designed By Justin Nam</h2>

            <?php if (isset($errors['login'])): ?>
                <div class="error-main">
                    <p><?php echo htmlspecialchars($errors['login']); ?></p>
                </div>
                <?php unset($errors['login']); ?>
            <?php endif; ?>

            <form method="POST" action="user-account.php">
                <div class="input-group">
                    <input 
                        type="email" 
                        name="email" 
                        id="email" 
                        placeholder="Please enter your Email" 
                        required 
                        style="text-align: center;"
                    >
                    <?php if (isset($errors['email'])): ?>
                        <div class="error">
                            <p><?php echo htmlspecialchars($errors['email']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="input-group password">
                    <input 
                        type="password" 
                        name="password" 
                        id="password" 
                        placeholder="Please enter your Password" 
                        required 
                        style="text-align: center;"
                    >
                    
                    <?php if (isset($errors['password'])): ?>
                        <div class="error">
                            <p><?php echo htmlspecialchars($errors['password']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <input type="submit" class="btn" value="Log In" name="login">
            </form>

            <p class="recover">
                <a href="forgot_password.php">Forgot Password</a>
            </p>

            <div class="contact-admin">
                <a href="mailto:nguyenhongnamjt@gmail.com" class="contact_admin_button">Contact Admin</a>
            </div>
            
            <div class="admin-login">
                <a href="admin_login.php" class="admin_login_button">Admin Login</a>
            </div>

            <div class="links">
                <p>Haven't got an account?</p>
<a href="register.php">Create Account</a>
            </div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const passwordField = document.getElementById('password');
                const toggleIcon = document.getElementById('eye');

                if (toggleIcon && passwordField) {
                    toggleIcon.addEventListener('click', () => {
                        const isPassword = passwordField.type === 'password';
                        passwordField.type = isPassword ? 'text' : 'password';
                        toggleIcon.classList.toggle('fa-eye');
                        toggleIcon.classList.toggle('fa-eye-slash');
                    });
                }
            });
        </script>
    </div>
</body>

</html>
<?php
if (isset($_SESSION['errors'])) {
    unset($_SESSION['errors']);
}
?>
