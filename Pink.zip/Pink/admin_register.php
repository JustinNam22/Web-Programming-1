<?php
// Start the session to use session variables
session_start();

// Check if the form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $admin_key = $_POST['admin_key'];

    // Initialize an array to store validation errors
    $errors = [];
    // Check if the username is empty and add an error if so
    if (empty($username)) {
        $errors['username'] = 'Username is required';
    }
    // Check if the password is empty and add an error if so
    if (empty($password)) {
        $errors['password'] = 'Password is required';
    }
    // Check if the admin key is correct, and add an error if it's invalid
    if ($admin_key !== '123') {
        $errors['admin_key'] = 'Incorrect admin key';
    }

    // If no validation errors, proceed with database interaction
    if (empty($errors)) {
        try {
            // Connect to the MySQL database using PDO
            $pdo = new PDO('mysql:host=localhost;dbname=hn', 'root', '');
            // Set the error mode to throw exceptions
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Hash the password for secure storage
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Prepare the SQL statement to insert the new admin data
            $stmt = $pdo->prepare('INSERT INTO admins (username, password) VALUES (:username, :password)');
            // Bind the form data to the prepared statement
            $stmt->bindParam(':username', $username);
            $stmt->bindParam(':password', $hashed_password);

            // Execute the query and check if it was successful
            if ($stmt->execute()) {
                // If the insertion is successful, set a success message in the session
                $_SESSION['success'] = 'Admin registered successfully';
                // Redirect to the admin login page
                header('Location: admin_login.php');
                exit(); // Terminate the script after the redirect
            }
        } catch (PDOException $e) {
            // Catch any database errors and store them in the errors array
            $errors['general'] = 'Database error: ' . $e->getMessage();
        }
    }

    // Store validation errors in the session for later display
    $_SESSION['errors'] = $errors;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Define character encoding for the page -->
    <meta charset="UTF-8">
    <!-- Set viewport for responsive design -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Set the page title -->
    <title>Chewsday | Create Admin Account</title>
    <!-- Link to external stylesheet for the page -->
    <link rel="stylesheet" href="admin_regizter.css">
    <!-- Link to Font Awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Link to Google Fonts for custom typography -->
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>
<body>
<div class="form-container">
    <!-- Heading for the form -->
    <h1>Create Admin Account</h1>
    
    <!-- Display error messages if there are any -->
    <?php if (isset($_SESSION['errors']) && !empty($_SESSION['errors'])): ?>
        <div class="error-container">
            <!-- Loop through each error and display it -->
            <?php foreach ($_SESSION['errors'] as $error): ?>
                <p class="error-message"><?php echo htmlspecialchars($error); ?></p>
            <?php endforeach; ?>
        </div>
    <?php unset($_SESSION['errors']); endif; ?>

    <!-- Admin account creation form -->
    <form method="POST">
        <!-- Input group for the username -->
        <div class="input-group">
            <input type="text" name="username" placeholder="Please enter Admin Username" required style="text-align: center;">
        </div>
        <!-- Input group for the password -->
        <div class="input-group password">
            <input type="password" name="password" placeholder="Please enter Password" required style="text-align: center;">
        </div>
        <!-- Input group for the admin key -->
        <div class="input-group">
            <input type="text" name="admin_key" placeholder="Please enter Admin Key" required style="text-align: center;">
        </div>
        <!-- Additional links and buttons -->
        <div class="additional-links">
            <!-- Submit button for the form -->
            <button type="submit">Create</button>  
            <!-- Link to the admin login page -->
            <a href="admin_login.php" class="back-links">Admin Login</a>
        </div>
    </form>
</div>
</body>
</html>
