<?php
// Start the session to manage user data
session_start();

// Include the database connection file
require 'dbConnect.php';

// Check if the user is logged in by verifying the session
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}

// Retrieve the user ID from the session data
$user_id = $_SESSION['user_id'];

// Get the post ID from the URL parameter, or set to null if not provided
$post_id = $_GET['post_id'] ?? null;

// Check if a post ID was provided
if (!$post_id) {
    // Display an error message and stop execution if no post ID is provided
    echo "Invalid post ID.";
    exit();
}

try {
    // Query the database to fetch all modules (assuming a 'modules' table exists)
    $stmt = $pdo->query("SELECT id, name FROM modules");
    // Fetch all modules as an associative array
    $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle any database errors during the query
    die("Database error: " . $e->getMessage());
}

try {
    // Prepare a query to fetch the post data for the given post ID and user ID
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
    $stmt->execute([$post_id, $user_id]);
    // Fetch the post data as an associative array
    $post = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the post exists for the given criteria
    if (!$post) {
        // Display an error message if the post is not found
        echo "Post not found";
        exit();
    }

    // Check if the form is submitted via POST request
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve the title from the form input
        $title = $_POST['title'];
        // Retrieve the content from the form input
        $content = $_POST['content'];
        // Retrieve the selected module ID from the form input
        $module_id = $_POST['module_id'];
        // Default to the existing image path unless a new image is uploaded
        $imagePath = $post['image'];

        // Check if a new image file is uploaded
        if (!empty($_FILES['image']['name'])) {
            // Define the target directory for image uploads
            $targetDir = "uploads/";
            // Construct the target path for the uploaded image
            $imagePath = $targetDir . basename($_FILES['image']['name']);
            // Attempt to move the uploaded file to the target directory
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
                // Display an error message if the upload fails
                echo "Failed to upload image.";
                exit();
            }
        }

        // Prepare a query to update the post with the new data
        $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, module_id = ?, image = ?, updated_at = NOW() WHERE id = ?");
        // Execute the query with the provided data
        $stmt->execute([$title, $content, $module_id, $imagePath, $post_id]);

        // Redirect to the home page after a successful update
        header("Location: home.php?post_id=$post_id");
        exit();
    }
} catch (PDOException $e) {
    // Handle any database errors during the process
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   
    <meta charset="UTF-8">
   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Chewsday | Edit Post (User)</title>
  
    <link rel="stylesheet" href="edit_p0st_user.css">
   
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Main container for the background styling -->
    <div class="background">
        <!-- Centered container for the form -->
        <div class="container">
            <!-- Page heading -->
            <h1>Edit Post</h1>
            <!-- Form for editing the post -->
            <form action="edit_post_user.php?post_id=<?php echo $post_id; ?>" method="post" enctype="multipart/form-data">
                <!-- Input field for the title -->
                <label for="title">Title: </label>
                <input type="text" name="title" id="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>

                <!-- Textarea for the content -->
                <label for="content">Content: </label>
                <textarea name="content" id="content" required><?php echo htmlspecialchars($post['content']); ?></textarea>

                <!-- Dropdown for selecting the module -->
                <label for="module_id">Module: </label>
                <select name="module_id" id="module_id" required>
                <?php foreach ($modules as $module): ?>
                    <!-- Populate the dropdown with module options -->
                    <option value="<?= htmlspecialchars($module['id']) ?>"><?= htmlspecialchars($module['name']) ?></option>
                <?php endforeach; ?>
                </select>

                <!-- Input field for image upload -->
                <label for="image">Upload Image: </label>
                <input type="file" name="image" id="image">
                <!-- Display the current image if available -->
                <?php if ($post['image']): ?>
                    <p><strong>Current Image: </strong><img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post Image" width="100"></p>
                <?php endif; ?>

                <!-- Submit button to update the post -->
                <button type="submit">Update Post</button>
            </form>
            <!-- Link to navigate back to the home page -->
            <a href="home.php" class="back-link">Back to Home Page</a>
        </div>
    </div>
</body>
</html>
